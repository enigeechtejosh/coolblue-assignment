<?php

use App\Pets\Presentation\Http\Controllers\PetController;
use Illuminate\Support\Facades\Route;

Route::get('/pets', [PetController::class, 'index']);
Route::post('/pets', [PetController::class, 'store']);
Route::get('/pets/{id}', [PetController::class, 'show']);
Route::put('/pets/{id}', [PetController::class, 'update']);
Route::delete('/pets/{id}', [PetController::class, 'destroy']);
Route::get('/pet-images/{id}/photo.webp', [PetController::class, 'image']);
